import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from reportlab.pdfgen import canvas

# ---------------- DATABASE ----------------
conn = sqlite3.connect("student_result.db")
cur = conn.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS users (
    username TEXT,
    password TEXT
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS results (
    roll TEXT,
    name TEXT,
    subject TEXT,
    marks INTEGER,
    grade TEXT
)
""")

cur.execute("INSERT OR IGNORE INTO users VALUES ('admin','1234')")
conn.commit()

# ---------------- GRADE ----------------
def grade(m):
    if m >= 80: return "A+"
    elif m >= 70: return "A"
    elif m >= 60: return "A-"
    elif m >= 50: return "B"
    else: return "F"

# ---------------- LOGIN ----------------
def login():
    u = user_entry.get()
    p = pass_entry.get()

    cur.execute("SELECT * FROM users WHERE username=? AND password=?", (u,p))
    if cur.fetchone():
        login_win.destroy()
        main_app()
    else:
        messagebox.showerror("Error", "Invalid Login")

login_win = tk.Tk()
login_win.title("Login")
login_win.geometry("300x200")
login_win.configure(bg="#1e1e1e")

tk.Label(login_win, text="LOGIN", fg="white", bg="#1e1e1e",
         font=("Arial",16,"bold")).pack(pady=10)

user_entry = tk.Entry(login_win)
user_entry.pack(pady=5)
user_entry.insert(0,"admin")

pass_entry = tk.Entry(login_win, show="*")
pass_entry.pack(pady=5)
pass_entry.insert(0,"1234")

tk.Button(login_win, text="Login", command=login,
          bg="green", fg="white").pack(pady=10)

# ---------------- MAIN APP ----------------
def main_app():
    root = tk.Tk()
    root.title("Student Result Management System")
    root.geometry("900x600")
    root.configure(bg="#121212")

    def clear():
        for e in (roll_e,name_e,sub_e,mark_e):
            e.delete(0,tk.END)

    def save():
        r,n,s,m = roll_e.get(), name_e.get(), sub_e.get(), mark_e.get()
        if not (r and n and s and m):
            messagebox.showerror("Error","All fields required")
            return
        g = grade(int(m))
        cur.execute("INSERT INTO results VALUES (?,?,?,?,?)",(r,n,s,m,g))
        conn.commit()
        load()
        clear()

    def load():
        tree.delete(*tree.get_children())
        cur.execute("SELECT * FROM results")
        for row in cur.fetchall():
            tree.insert("",tk.END,values=row)

    def delete():
        selected = tree.focus()
        if not selected: return
        r = tree.item(selected)["values"][0]
        cur.execute("DELETE FROM results WHERE roll=?", (r,))
        conn.commit()
        load()

    def update():
        selected = tree.focus()
        if not selected: return
        r,n,s,m = roll_e.get(), name_e.get(), sub_e.get(), mark_e.get()
        g = grade(int(m))
        cur.execute("""UPDATE results 
                       SET name=?, subject=?, marks=?, grade=?
                       WHERE roll=?""",(n,s,m,g,r))
        conn.commit()
        load()

    def select(event):
        item = tree.item(tree.focus())["values"]
        if not item: return
        roll_e.delete(0,tk.END); roll_e.insert(0,item[0])
        name_e.delete(0,tk.END); name_e.insert(0,item[1])
        sub_e.delete(0,tk.END); sub_e.insert(0,item[2])
        mark_e.delete(0,tk.END); mark_e.insert(0,item[3])

    def export_pdf():
        pdf = canvas.Canvas("Result_Report.pdf")
        pdf.drawString(200,800,"Student Result Report")
        y = 760
        cur.execute("SELECT * FROM results")
        for r in cur.fetchall():
            pdf.drawString(50,y,f"{r}")
            y -= 20
        pdf.save()
        messagebox.showinfo("PDF","Result_Report.pdf Created")

    # ---------------- UI ----------------
    tk.Label(root,text="Student Result Management System",
             bg="#121212", fg="white",
             font=("Arial",18,"bold")).pack(pady=10)

    f = tk.Frame(root,bg="#121212")
    f.pack()

    labels = ["Roll","Name","Subject","Marks"]
    entries = []
    for i,l in enumerate(labels):
        tk.Label(f,text=l,bg="#121212",fg="white").grid(row=i,column=0)
        e = tk.Entry(f)
        e.grid(row=i,column=1,pady=2)
        entries.append(e)

    roll_e,name_e,sub_e,mark_e = entries

    tk.Button(f,text="Save",command=save,bg="green",fg="white").grid(row=4,column=0)
    tk.Button(f,text="Update",command=update,bg="blue",fg="white").grid(row=4,column=1)
    tk.Button(f,text="Delete",command=delete,bg="red",fg="white").grid(row=5,column=0)
    tk.Button(f,text="Export PDF",command=export_pdf,bg="purple",fg="white").grid(row=5,column=1)

    cols = ("Roll","Name","Subject","Marks","Grade")
    tree = ttk.Treeview(root,columns=cols,show="headings")
    for c in cols:
        tree.heading(c,text=c)
    tree.pack(expand=True,fill="both",pady=10)
    tree.bind("<<TreeviewSelect>>",select)

    load()
    root.mainloop()

login_win.mainloop()
